module com.example.lab3_loyd {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lab3_loyd to javafx.fxml;
    exports com.example.lab3_loyd;
}